/**
 * 
 */
/**
 * 
 */
module GoShoppingApp {
}